Il y a 2 fichiers logisim : le base est le fichier sans les instructions bonus
			    le nvlInstructions est le fichier incluant les 3 instructions en plus
